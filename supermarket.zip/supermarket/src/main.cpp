#include "../include/App.hpp"

int main(int argc, char **argv) {
  App app;

  app.run(argc, argv);

  return 0;
}
